CREATE  USER petar IDENTIFIED by &pass;

GRANT "DBA" TO petar;

UNDEFINE pass;